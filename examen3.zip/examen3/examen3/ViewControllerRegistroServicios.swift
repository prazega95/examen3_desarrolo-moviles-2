//
//  ViewControllerRegistroServicios.swift
//  examen3
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 DAMII. All rights reserved.
//

import UIKit

class ViewControllerRegistroServicios: UIViewController {
    
    
    @IBOutlet weak var tfCodigo: UITextField!
    @IBOutlet weak var tfCliente: UITextField!
    @IBOutlet weak var tfNroorden: UITextField!
    @IBOutlet weak var tfFecha: UITextField!
    @IBOutlet weak var tfLinea: UITextField!
    @IBOutlet weak var tfEstado: UITextField!
    @IBOutlet weak var tfObservaciones: UITextField!
    
    @IBOutlet weak var lblMensaje: UILabel!
    
    var objServiciosInternoRegistro: ObjListar!
   
    
    public func CargarREgistro(pServ: ObjListar)
    {
        self.objServiciosInternoRegistro = pServ
    }


    
    func MostrarDatos()
       {
           tfCodigo.text = String(objServiciosInternoRegistro.CodigoServicio)
           tfCliente.text = objServiciosInternoRegistro.NombreCliente
           tfNroorden.text = objServiciosInternoRegistro.NumeroOrdenServicio
           tfFecha.text = objServiciosInternoRegistro.Fecha
           tfLinea.text = objServiciosInternoRegistro.Linea
           tfEstado.text = objServiciosInternoRegistro.Estado
           tfObservaciones.text = objServiciosInternoRegistro.Observaciones
       }

    
    
    
    @IBAction func btnRegresar_Onclick(_ sender: Any) {
     
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let oPantalla2 = storyBoard.instantiateViewController(withIdentifier: "ViewListarServicios") as! ViewControllerListarServicios
                                           
            self.present(oPantalla2, animated: true, completion: nil)
    
    }
    
    
    @IBAction func btnGrabar_Onclick(_ sender: Any) {
        
        var pTipoTransaccion:String="N"
        self.lblMensaje.text = "Nuevo Servicio Registrado!"
        
        if (objServiciosInternoRegistro.CodigoServicio>0)
        {
           pTipoTransaccion = "A"
            self.lblMensaje.text = "Servicio Actualizado!"
        }
        
   
        
        let urlListado = "http://cibertec202021-001-site1.etempurl.com/Servicio/RegistraModifica?Accion=" + pTipoTransaccion +
                   "&CodigoServicio=" + String(objServiciosInternoRegistro.CodigoServicio) +
                   "&NombreCliente=" + self.tfCliente.text! +
                   "&NumeroOrdenServicio=" + self.tfNroorden.text! +
                   "&FechaProgramada=" + self.tfFecha.text! +
                   "&Linea=" + self.tfLinea.text! +
                   "&Estado=" + self.tfEstado.text! +
                   "&Observaciones=" + self.tfObservaciones.text!
        
                       print (urlListado)
                       let urlConsulta = URL(string: urlListado)
                       let peticion = URLRequest(url: urlConsulta!)
                       
                       let tarea = URLSession.shared.dataTask(with: peticion)
                       {Datos, Respuesta, Error in
                           print("por iniciar")
                           if (Error == nil)
                           {
                               print("Por procesar Datos")
                               print(Datos ?? "Vacio")
                               let datosCadena = NSString(data: Datos!, encoding: String.Encoding.utf8.rawValue)
                               print (datosCadena!)
                               print("Fin procesar Datos")
                               
                               DispatchQueue.main.async {
                                   //Inicio Completar la lectura de objetos JSON
                                   let JSON = try? JSONSerialization.jsonObject(with: Datos!, options: [])
                                   
                                    if let objProveedortmp = JSON as? [String: Any]
                                                      {
                                           let CodigoServicio = objProveedortmp["CodigoServicio"] as! integer_t
                                                       self.objServiciosInternoRegistro.CodigoServicio = CodigoServicio
                                                       self.tfCodigo.text = String (CodigoServicio)
                                             
                                   }
                                   //Fin Completar la lectura de objetos JSON
                               }
                               //let resultado = datosCadena! as String
                           }
                           else
                           {
                               print("Error")
                               print(Error ?? "Error vacio")
                            self.lblMensaje.text = "Error!!"
                               //let strCadena = Error as! String
                               //self.tvMensaje.text = strCadena
                           }
                       }
                       tarea.resume()
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.MostrarDatos()

        // Do any additional setup after loading the view.
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
