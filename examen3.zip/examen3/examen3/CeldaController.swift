//
//  CeldaController.swift
//  examen3
//
//  Created by DAMII on 7/20/20.
//  Copyright © 2020 DAMII. All rights reserved.
//

import UIKit

class CeldaController: UICollectionViewCell {
    
}
