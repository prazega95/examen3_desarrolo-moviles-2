//
//  TableViewCellServicios.swift
//  examen3
//
//  Created by DAMII on 7/19/20.
//  Copyright © 2020 DAMII. All rights reserved.
//

import UIKit

class TableViewCellServicios: UITableViewCell {
    
    
   
    @IBOutlet weak var lblNroorden: UILabel!
    @IBOutlet weak var lblCliente: UILabel!
    @IBOutlet weak var lblFecha: UILabel!
    @IBOutlet weak var btnVerRegistro: UIButton!
    
    
    
    var objServiciosInterno: ObjListar!
    var ObjSelf: ViewControllerListarServicios!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
    @IBAction func btnver_onclick(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
               let oPantalla2 = storyBoard.instantiateViewController(withIdentifier: "ViewRegistroServicios") as! ViewControllerRegistroServicios
               oPantalla2.CargarREgistro(pServ: objServiciosInterno)
                          
                  ObjSelf.present(oPantalla2, animated: true, completion: nil)
    }
    

    public func MostrarRegistro(pServicios: ObjListar, pSelf: ViewControllerListarServicios)
       {
           self.objServiciosInterno = pServicios
           self.lblNroorden.text = pServicios.NumeroOrdenServicio
           self.lblCliente.text = pServicios.NombreCliente
           self.lblFecha.text = pServicios.Fecha
           self.ObjSelf = pSelf
           
       }
    
}
